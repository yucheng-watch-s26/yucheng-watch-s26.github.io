#!/usr/bin/env python3
"""
YCBT Watch — real-time BLE client (YC be940000 protocol).

Device E2:D5:1F:01:8E:A1 confirms be940000 service:
  be940001  [write-without-response, write, indicate]  ← write + responses
  be940002  [write-without-response, write]             ← secondary write
  be940003  [indicate]                                  ← responses

Usage:
    pip install bleak
    python main.py [MAC]        # real-time HR + BP + SpO2 (default)
    python main.py [MAC] --hr   # HR only
    python main.py [MAC] --bp   # BP only
    python main.py [MAC] --raw  # dump every raw frame (debug)
"""
import asyncio, struct, sys, time, datetime
from bleak import BleakClient, BleakScanner

DEFAULT_MAC = "E2:D5:1F:01:8E:A1"

# ── YC custom service ──────────────────────────────────────────────────────
YC_WRITE   = "be940001-7333-be46-b7ae-689e71722bd5"  # write + indicate
YC_NOTIFY  = "be940003-7333-be46-b7ae-689e71722bd5"  # indicate (device→app)

# Standard GATT (kept for battery / GATT HR fallback)
HR_MEAS    = "00002a37-0000-1000-8000-00805f9b34fb"
BAT_LEVEL  = "00002a19-0000-1000-8000-00805f9b34fb"
MANUFACTURER = "00002a29-0000-1000-8000-00805f9b34fb"

# ── dataType constants  (group<<8 | key, from CMD.java + Constants.java) ──
DT_TIME_SYNC    = 0x0100   # Setting  key=0  — sync clock
DT_HEART_ON     = 0x0301   # AppCtrl  key=1  — HeartTest on/off
DT_BLOOD_ON     = 0x0302   # AppCtrl  key=2  — BloodTest on/off
DT_BLOOD_CHECK  = 0x0303   # AppCtrl  key=3  — BloodCheck (SpO2) on/off
DT_REAL_STREAM  = 0x0309   # AppCtrl  key=9  — real-time stream on/off
DT_BP_MEASURE   = 0x032F   # AppCtrl  key=47 — AppStartMeasurement: one-shot BP measure
DT_GET_REAL     = 0x0220   # Get      key=32 — GetAllRealDataFromDevice: fetch result

# ── response dataTypes  (device→app, from DataUnpack.java) ────────────────
RT_HR    = 0x0601   # Real UploadHeart:  payload[0]=BPM
RT_BLOOD = 0x0603   # Real UploadBlood:  payload[0]=SBP, [1]=DBP, [2]=HR
RT_SPO2  = 0x0602   # Real UploadBloodOxygen: payload[0]=%
RT_DONE  = 0x040E   # DeviceMeasurementResult: [0]=type, [1]=1ok/2fail
RT_COMP  = 0x060A   # Real UploadComprehensive (multi-field)


# ══════════════════════════════════════════════════════════════════════════
# YC frame codec  (YCBTClientImpl.sendData2Device + ByteUtil.crc16_compute)
# ══════════════════════════════════════════════════════════════════════════

def _crc16(data: bytes) -> int:
    s = 0xFFFF
    for b in data:
        s = (((s << 8) & 0xFF00) | ((s >> 8) & 0xFF)) ^ (b & 0xFF)
        s ^= (s & 0xFF) >> 4
        s ^= (s << 12) & 0xFFFF
        s ^= ((s & 0xFF) << 5) & 0xFFFF
    return s & 0xFFFF


def frame(dt: int, payload: bytes = b"") -> bytes:
    group, key = (dt >> 8) & 0xFF, dt & 0xFF
    n = len(payload) + 6
    hdr = bytes([group, key, n & 0xFF, n >> 8]) + payload
    c = _crc16(hdr)
    return hdr + bytes([c & 0xFF, c >> 8])


def parse(data: bytes) -> dict | None:
    if len(data) < 6:
        return None
    g, k = data[0], data[1]
    n = data[2] | (data[3] << 8)
    if n != len(data):
        return None
    return {"dt": (g << 8) | k, "g": g, "k": k, "p": bytes(data[4:n - 2])}


def ts() -> str:
    return datetime.datetime.now().strftime("%H:%M:%S")


def show(pkt: dict, raw: bool) -> None:
    dt, p = pkt["dt"], pkt["p"]
    if dt == RT_HR and p:
        print(f"[{ts()}]  HR    {p[0]:3} BPM")
    elif dt == RT_BLOOD and len(p) >= 2:
        hr = f"  HR {p[2]} BPM" if len(p) > 2 and p[2] else ""
        print(f"[{ts()}]  BP    {p[0]}/{p[1]} mmHg{hr}")
    elif dt == RT_SPO2 and p:
        print(f"[{ts()}]  SpO2  {p[0]} %")
    elif dt == RT_COMP and len(p) >= 11:
        print(f"[{ts()}]  COMP  HR={p[7]}  BP={p[8]}/{p[9]}  SpO2={p[10]}")
    elif dt == RT_DONE and len(p) >= 2:
        st = {1: "OK", 2: "FAIL", 3: "CANCEL"}.get(p[1], f"?{p[1]}")
        print(f"[{ts()}]  DONE  type={p[0]} {st}")
    else:
        # Always print unknown frames so nothing is silently lost
        print(f"[{ts()}]  RAW   g={pkt['g']:02X} k={pkt['k']:02X}  {p.hex(' ').upper() or '(empty)'}")


# ══════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════

async def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("mac", nargs="?", default=DEFAULT_MAC)
    ap.add_argument("--hr",  action="store_true", help="HR only")
    ap.add_argument("--bp",  action="store_true", help="BP only")
    ap.add_argument("--raw", action="store_true", help="dump all raw frames")
    args = ap.parse_args()

    mac = args.mac
    if mac == DEFAULT_MAC and len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
        mac = sys.argv[1]

    # Determine which commands to send
    if args.hr:
        cmds_on  = [(DT_HEART_ON, b"\x01"), (DT_REAL_STREAM, b"\x01")]
        cmds_off = [(DT_REAL_STREAM, b"\x00"), (DT_HEART_ON, b"\x00")]
        mode = "HR only"
    elif args.bp:
        cmds_on  = [
            (DT_BLOOD_ON,    b"\x01"),
            (DT_REAL_STREAM, b"\x01"),
            (DT_BP_MEASURE,  b"\x01\x01"),  # one-shot measure + stream result
        ]
        cmds_off = [
            (DT_BP_MEASURE,  b"\x00\x01"),
            (DT_REAL_STREAM, b"\x00"),
            (DT_BLOOD_ON,    b"\x00"),
        ]
        mode = "BP only"
    else:
        # Default: all real-time metrics
        cmds_on  = [
            (DT_HEART_ON,    b"\x01"),
            (DT_BLOOD_ON,    b"\x01"),
            (DT_BLOOD_CHECK, b"\x01"),
            (DT_REAL_STREAM, b"\x01"),
        ]
        cmds_off = [
            (DT_REAL_STREAM, b"\x00"),
            (DT_BLOOD_CHECK, b"\x00"),
            (DT_BLOOD_ON,    b"\x00"),
            (DT_HEART_ON,    b"\x00"),
        ]
        mode = "all metrics"

    print(f"Connecting to {mac}  [{mode}]...")

    async with BleakClient(mac, timeout=15.0) as client:
        print(f"Connected.\n")

        all_chars = {c.uuid: c for svc in client.services for c in svc.characteristics}

        # Static info
        for uuid, label in [(MANUFACTURER, "Manufacturer"), (BAT_LEVEL, "Battery   ")]:
            if uuid in all_chars:
                try:
                    d = await client.read_gatt_char(uuid)
                    val = d.decode("utf-8", errors="replace") if uuid == MANUFACTURER else f"{d[0]} %"
                    print(f"  {label}: {val}")
                except Exception:
                    pass

        if YC_WRITE not in all_chars:
            print("ERROR: be940001 not found — is the device paired?")
            return

        # Subscribe to both indication chars (both can carry device→app frames)
        def on_data(_, data: bytearray) -> None:
            pkt = parse(bytes(data))
            if pkt:
                show(pkt, args.raw)
                # After measurement completes OK, auto-fetch the stored result
                if pkt["dt"] == RT_DONE and len(pkt["p"]) >= 2 and pkt["p"][1] == 1:
                    asyncio.ensure_future(
                        client.write_gatt_char(YC_WRITE, frame(DT_GET_REAL, b""))
                    )
            elif args.raw:
                print(f"[{ts()}]  MALFORMED  {bytes(data).hex(' ').upper()}")

        await client.start_notify(YC_WRITE,  on_data)   # be940001 indicate
        await client.start_notify(YC_NOTIFY, on_data)   # be940003 indicate

        # Subscribe to standard GATT HR as well (passive fallback)
        if HR_MEAS in all_chars:
            def on_gatt_hr(_, data: bytearray) -> None:
                flags = data[0]
                hr = struct.unpack_from("<H", data, 1)[0] if flags & 1 else data[1]
                print(f"[{ts()}]  GATT-HR  {hr:3} BPM")
            await client.start_notify(HR_MEAS, on_gatt_hr)

        # Sync device clock
        epoch_yc = int(time.time()) - 946684800   # YC epoch starts 2000-01-01
        await client.write_gatt_char(YC_WRITE, frame(DT_TIME_SYNC, struct.pack("<I", epoch_yc)))

        # Send measurement start commands
        for dt, payload in cmds_on:
            await client.write_gatt_char(YC_WRITE, frame(dt, payload))
            await asyncio.sleep(0.05)

        print(f"\n── Streaming {mode} (Ctrl+C to stop) ──────────────────────────\n")

        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            print("\nStopping...")
            for dt, payload in cmds_off:
                try:
                    await client.write_gatt_char(YC_WRITE, frame(dt, payload))
                    await asyncio.sleep(0.05)
                except Exception:
                    pass
            print("Done.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nStopped")
